<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Admin\UserReview;

class UserReviewController extends Controller
{
  
}
