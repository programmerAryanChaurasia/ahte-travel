<div class="destop-right-content">
    

</div>
<?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/layouts/frontend/right_content.blade.php ENDPATH**/ ?>