<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-name', 'Plan Your Trip List'); ?>

<?php $__env->startSection('back-page'); ?>
<a href="<?php echo e(route('dashboard.index')); ?>"> Dashboard &nbsp; >  &nbsp;</a>
<a href="<?php echo e(route('admin.plan-your-trips.create')); ?>"> Create Trip &nbsp; > &nbsp;</a> List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="panel important">
    <div class="container-fluid table-responsive px-5 py-3">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <table id="example" class="table table-striped" style="width:100%">
            <thead>
                <tr>
                    <th scope="col" class="datatable-thead-style" >#</th>
                    <th scope="col" class="datatable-thead-style">Name</th>
                    <th scope="col" class="datatable-thead-style">From City</th>
                    <th scope="col" class="datatable-thead-style">To City</th>
                    <th scope="col" class="datatable-thead-style">Count</th>
                    <th scope="col" class="datatable-thead-style">Phone</th>
                    <th scope="col" class="datatable-thead-style">Status</th>
                    <th scope="col" class="datatable-thead-style">Last Contact Date</th>
                    <th scope="col" class="datatable-thead-style">Future Contact Date</th>
                    <th scope="col" class="datatable-thead-style">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $planYourTrips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($trip->name); ?></td>
                    <td><?php echo e($trip->from_city); ?></td>
                    <td><?php echo e($trip->to_city); ?></td>
                    <td><?php echo e($trip->number_of_people); ?></td>
                    <td><?php echo e($trip->phone_number); ?></td>
                    <td>
                        <?php if($trip->status == 0): ?>
                            <span class="status-badge bg-warning">
                                <i class="fas fa-clock"></i> Pending
                            </span>
                        <?php elseif($trip->status == 1): ?>
                            <span class="status-badge bg-info">
                                <i class="fas fa-phone"></i> Contacted
                            </span>
                        <?php elseif($trip->status == 2): ?>
                            <span class="status-badge bg-success">
                                <i class="fas fa-check-circle"></i> Confirmed
                            </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($trip->last_contact_date ? \Carbon\Carbon::parse($trip->last_contact_date)->format('d-m-Y') : 'N/A'); ?>

                    </td>
                    <td>
                        <?php echo e($trip->future_contact_date ? \Carbon\Carbon::parse($trip->future_contact_date)->format('d-m-Y') : 'N/A'); ?>

                    </td>
                    <td>
                        <div class="action-buttons">
                            <!-- Edit Button -->
                            <a href="<?php echo e(route('admin.plan-your-trips.edit', $trip->id)); ?>" class="btn btn-primary btn-sm" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>

                            <!-- Delete Button with Modal Trigger -->
                            <button class="btn btn-danger btn-sm" title="Delete" data-toggle="modal" data-target="#deleteModal<?php echo e($trip->id); ?>">
                                <i class="fas fa-trash-alt"></i>
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="deleteModal<?php echo e($trip->id); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <?php echo e($trip->name); ?>

                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            Are you sure you want to delete <b><?php echo e($trip->name); ?></b>?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                            <!-- The form that submits for deletion -->
                                            <form action="<?php echo e(route('admin.plan-your-trips.destroy', $trip->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Confirm Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="empty-state text-center">
                        No trips found
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>


        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/admin/plan-your-trips/index.blade.php ENDPATH**/ ?>