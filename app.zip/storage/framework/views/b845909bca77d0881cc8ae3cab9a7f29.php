<?php $__env->startSection('page-name','Category List'); ?>

<?php $__env->startSection('back-page'); ?>
<a href="<?php echo e(route('dashboard.index')); ?>" > Dashboard &nbsp; >  &nbsp;</a> <a href="<?php echo e(route('admin.category.index')); ?>" > Create Category &nbsp; > &nbsp;</a>  List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="panel important">

        <div class="container-fluid table-responsive px-5 py-3">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <table class="table table-bordered table-hover">
              <thead class="thead-dark" style="background-color: black;color:#fff">
                <tr>
                  <th scope="col" width="5%">#</th>
                  <th scope="col" width="15%">Name</th>
                  <th scope="col" width="15%">Slug</th>
                  <th scope="col" width="50%">Description</th>
                  <th scope="col" width="15%">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($cat->category); ?></td>
                    <td><?php echo e($cat->slug); ?></td>
                    <td><?php echo e($cat->description); ?></td>
                    <td>
                      <span>
                          <div class="row">
                              <div class="col-sm-6">
                                  <form action="<?php echo e(route('admin.category.edit')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" value="<?php echo e($cat->slug); ?>" name="slug">
                                      <button class="btn btn-primary" type="submit">Edit</button>
                                  </form>

                              </div>
                              <div class="col-sm-6">
                                  <form action="<?php echo e(route('admin.category.delete')); ?>" onsubmit="return confirm('Do you really want to Delete the record?');" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" value="<?php echo e($cat->slug); ?>" name="slug">
                                      <button class="btn btn-danger" type="submit">Delete</button>
                                  </form>
                              </div>
                          </div>
                      </span>

                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>


              </tbody>
            </table>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/admin/category/list.blade.php ENDPATH**/ ?>