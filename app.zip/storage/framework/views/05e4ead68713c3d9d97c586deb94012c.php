<style>
    .mobile-sidebar-item{
        margin-left: 10px;
    }
    .sidebar a{
        margin-top: 10px;
    }
</style>
<div class="mobile-sidebar">
    <div id="myNav" class="overlay">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="sidebar mobile-sidebar-item">
            
            <span>Web Development</span>
            <a href="#"> HTML Tutorial</a>
            <a href="#">CSS Tutorial</a>
            <a href="#">JavaScript Tutorial</a>
            <a href="#">jQuery Tutorial</a>
            <a href="#">Bootstrap Tutorial</a>
            <a href="#">PHP Tutorial</a>
            <a href="#">SQL Tutorial</a>
            <a href="#"> HTML Examples</a>
            <a href="#">CSS Examples</a>
            <a href="#">JavaScript Examples</a>
            <a href="#">jQuery Examples</a>
            <a href="#">Bootstrap Examples</a>
            <a href="#">PHP Examples</a>
            <a href="#">HTML Tags/Elements</a>
            <a href="#">HTML Global Attributes</a>
            <a href="#">HTML Event Attributes</a>
            <a href="#">HTML Color Picker</a>
            <a href="#">HTML Language Codes</a>
            <a href="#">HTML Character Entities</a>
            <a href="#">HTTP Status Codes</a>
            <a href="#">CSS At-rules</a>
            <a href="#">CSS Properties</a>
            <a href="#">CSS Animatable Properties</a>
            <a href="#">CSS Color Values</a>
            <a href="#">CSS Color Names</a>
            <a href="#">CSS Web Safe Fonts</a>
            <a href="#">CSS Aural Properties</a>
            <a href="#">PHP Array Functions</a>
            <a href="#">PHP String Functions</a>
            <a href="#">PHP File System Functions</a>
            <a href="#">PHP Date/Time Functions</a>
            <a href="#">PHP Calendar Functions</a>
            <a href="#">PHP MySQLi Functions</a>
            <a href="#">PHP Filters</a>
            <a href="#">PHP Error Levels</a>


        </div>
    </div>

</div>
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/frontend/mobile_sidebar-post.blade.php ENDPATH**/ ?>