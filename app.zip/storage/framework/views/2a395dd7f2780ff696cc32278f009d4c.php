
   <!-- Header Second -->
    <div class="header2">
        <div class="container-fluid" style="background-color: #f9f9fb; height: 40px;">
            <div class="scrollmenu">
                <a href="/">Home</a>
                <?php $__empty_1 = true; $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="/<?php echo e($cat->slug); ?>"><?php echo e($cat->category); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?>

            </div>
        </div>
    </div>


<!-- Header Second -->
<?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/layouts/frontend/header2.blade.php ENDPATH**/ ?>