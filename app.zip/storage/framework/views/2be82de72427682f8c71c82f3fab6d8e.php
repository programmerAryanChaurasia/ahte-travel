<?php echo $__env->make('layouts.admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main role="main">

        <section class="panel important">

            <h2 style="float: left;">
                <li><?php echo $__env->yieldContent('page-name'); ?></li>
            </h2>
            <span style="float: right; margin-top:20px;" class="p-3"> <?php echo $__env->yieldContent('back-page'); ?> </span>

        </section>

        <?php echo $__env->yieldContent('content'); ?>

    </main>


    
    <script src="<?php echo e(asset('vender/jquery-3.7.1.min.js')); ?>"></script>

    
    <script src = "https://cdn.ckeditor.com/ckeditor5/40.1.0/super-build/ckeditor.js" > </script>
    <script src="<?php echo e(asset('admins/vender/ckeditor.js')); ?>"></script>

    <script>
        $(document).ready(function() {

            $("#change-category").change(function() {

                var cat_id = $(this).val();



                $.ajax({
                    url: '/admin/post/get-sub-category',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {cat_id:cat_id},
                    success: function(response) {
                        // Handle success (e.g., update UI, close modal, etc.)

                        $("#change-category-then-subcategory").empty();
                        $.each(response, function(key, value) {
                            // console.log("key = "+key,"value = "+value.id);
                            $("#change-category-then-subcategory").append('<option value="'+value.id+'">'+value.sub_category+'</option>')

                        });

                        $.each(response, function(key, value) {
                            console.log("key2 = "+key,"value = "+value.sub_category);

                        });
                        // console.log(response);
                    },
                    error: function(error) {
                        // Handle error (e.g., display error message)
                        console.log(error);
                    }
                });

            });

        });
    </script>

</body>

</html>
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/admin/layout.blade.php ENDPATH**/ ?>