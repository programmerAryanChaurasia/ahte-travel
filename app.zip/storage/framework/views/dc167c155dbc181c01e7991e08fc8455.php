<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="<?php echo e(asset('admins/vender/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/10.7.2/styles/tomorrow-night.min.css">

<?php echo $__env->make('layouts.frontend.meta_tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">

<title>Home</title>
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/frontend/head.blade.php ENDPATH**/ ?>