<?php $__env->startSection('page-name','Post List'); ?>

<?php $__env->startSection('back-page'); ?>
<a href="#" > Page1 &nbsp; >  &nbsp;</a> <a href="#" > Page2 &nbsp; > &nbsp;</a> <a href="#" > Page3 </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="panel important mb-5">

        <div class="container-fluid table-responsive px-5 py-3">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <table class="table table-bordered table-hover">
              <thead class="thead-dark" style="background-color: black;color:#fff">
                <tr>
                    <th scope="col" >#</th>
                    <th scope="col">Title</th>
                    <th scope="col" >Category</th>
                    <th scope="col" >Sub Category</th>
                    <th scope="col" >Sub Category Slug</th>
                    <th scope="col" >Short Description</th>
                    <th scope="col" >Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row">1</th>
                    <td> <?php echo e($post->title_tag ?? ''); ?></td>
                    <td><?php echo e($post->category ?? ''); ?></td>
                    <td><?php echo e($post->sub_category ?? ''); ?></td>
                    <td><?php echo e($post->sub_category_slug  ?? ''); ?></td>
                    <td><?php echo e($post->sort_description ?? ''); ?></td>
                    <td>
                        <span>
                            <div class="row">
                                <div class="col-sm-6">
                                    <form action="<?php echo e(route('admin.post.edit')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($post->id); ?>" name="id">
                                        <button class="btn btn-primary" type="submit">Edit</button>
                                    </form>

                                </div>
                                <div class="col-sm-6">
                                    <form action="<?php echo e(route('admin.post.delete')); ?>" onsubmit="return confirm('Do you really want to Delete the record?');" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($post->id); ?>" name="id">
                                        <button class="btn btn-danger" type="submit">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </span>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>

              </tbody>
            </table>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel projects\website\datascience\resources\views/admin/post/list.blade.php ENDPATH**/ ?>