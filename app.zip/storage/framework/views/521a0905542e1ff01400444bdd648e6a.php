<style>
    hr.line{
        width: 90%;
        margin: 0px auto;
        margin-bottom: 8px;
    }
    hr.line::after {
        content: '§';
        display: inline-block;
        position: absolute;
        left: 50%;
        transform: translate(-50%, -50%) rotate(60deg);
        transform-origin: 50% 50%;
        padding: 1rem;
        background-color: white;


    }
</style>
<?php $__env->startSection('content'); ?>
<div class="" style="border: 1px solid rgba(232, 232, 226, 0.713); margin:15px; background-color: rgba(232, 232, 226, 0.713);">
    <div class="col-sm-12">
        <img src="<?php echo e(asset('frontend/image/home 1.jpg')); ?>"  class="img-fluid" alt="">
    </div>
</div>
<div class="">
    <h1 >My goal is to become a data scientist</h1>
    <hr class="" style="color:#8e9aa6; width:80%; margin:5px auto;">
    <span class="mb-2" style="font-size: 15px; color:#8e9aa6;">Learn Data Science (Python, Numpy, Pandas, ML, Deep Learning...) And Build Application</span>
    <hr class="" style="color:#8e9aa6; width:80%; margin:5px auto;">

    <h2  style="font-weight:600;">Welcome to Neuro Ved</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Error facere blanditiis ex dolore odio accusamus quos aliquid fuga, repellendus, numquam reprehenderit adipisci eligendi corporis inventore est et animi deserunt debitis. </p>

    <hr class="line" style="color:#8e9aa6;">
    <h2 class="" style="font-weight:600;">Steps to learn</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime, qui. Cumque animi eum beatae sunt et quo nobis saepe, modi dicta quis amet enim eligendi reprehenderit consequuntur quos adipisci</p>

    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Python</h2>
        <div class="row mb-3">

            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Python</a></span>
            </div>
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/python.png')); ?>" class="mb-2 img-fluid" alt=""></div>
        </div>
    </div>


    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Numpy</h2>
        <div class="row mb-3">
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/numpy.jpg')); ?>"  class="mb-2 img-fluid" alt=""></div>
            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Numpy</a></span>
            </div>

        </div>
    </div>


    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Pandas</h2>
        <div class="row mb-3">

            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Pandas</a></span>
            </div>
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/Pandas.png')); ?>"  class="mb-2 img-fluid" alt=""></div>

        </div>
    </div>


    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Seaborn</h2>
        <div class="row mb-3">
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/seaborn.jpg')); ?>"  class="mb-2 img-fluid" alt=""></div>
            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Seaborn</a></span>
            </div>

        </div>
    </div>

    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">MatPlotlib</h2>
        <div class="row mb-3">

            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">MatPlotlib</a></span>
            </div>
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/matplotlib.jpg')); ?>"  class="mb-2 img-fluid" alt=""></div>
        </div>
    </div>

    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Probability</h2>
        <div class="row mb-3">
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/probability.jpg')); ?>" style="max-height: 150px;"  class="mb-2 img-fluid" alt=""></div>
            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Probability</a></span>
            </div>

        </div>
    </div>

    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Statistics</h2>
        <div class="row mb-3">

            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Statistics</a></span>
            </div>
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/statistics.jpg')); ?>"  class="mb-2 img-fluid" alt=""></div>
        </div>
    </div>

    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Machin Learning</h2>
        <div class="row mb-3">
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/machine_learning.jpg')); ?>"  class="mb-2 img-fluid" alt=""></div>
            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Machin Learning</a></span>
            </div>

        </div>
    </div>

    <div>
        <hr class="line" style="color:#8e9aa6;">
        <h2 class="" style="font-weight:600;">Deep Learning</h2>
        <div class="row mb-3">

            <div class="col-sm-7">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati porro impedit dicta nisi temporibus non. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Incidunt quas alias harum quaerat consequuntur rem?
                <br><br>
            <span>Now Start 1st Step <a href="#">Deep Learning</a></span>
            </div>
            <div class="col-sm-5"><img src="<?php echo e(asset('frontend/image/home-page-image/deepLearning.png')); ?>"  class="mb-2 img-fluid" alt=""></div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel projects\website\datascience\resources\views/frontend/home.blade.php ENDPATH**/ ?>