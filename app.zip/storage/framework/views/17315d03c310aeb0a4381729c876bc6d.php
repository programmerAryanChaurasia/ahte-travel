

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <meta name="keywords" content="<?php echo e($post->meta_keyword ?? ''); ?>">
    

    <meta name="description" content="<?php echo e($post->meta_description ?? ''); ?>">
   

    
   

    <meta name="subject" content="<?php echo e($post->meta_subject ?? ''); ?>">
   

    <meta name="copyright" content="Neuro Ved">
   

    <meta name="language" content="Englsh">
   

    <meta name="robots" content="<?php echo e($post->robots_tag ?? ''); ?>">
   

    

    <meta name="revised" content="<?php echo e($post->meta_revised ?? ''); ?>"> 
   

    <meta name="abstract" content="<?php echo e($post->meta_abstract ?? ''); ?>">
   

    <meta name="topic" content="<?php echo e($post->meta_topic ?? ''); ?>">
   

    <meta name="summary" content="<?php echo e($post->meta_summary ?? ''); ?>">
   

    <meta name="Classification" content="">
   

    <meta name="author" content="Aryan Chaurasia, neuroved@gmail.com">
   

    <meta name="designer" content="">
   

    <meta name="reply-to" content="neuroved@gmail.com">
   

    <meta name="owner" content="Neuro Ved">
   

    <meta name="url" content="http://www.neuroved.com">
   

    <meta name="identifier-URL" content="http://www.websiteaddress.com">
   

    <meta name="directory" content="">
   


    <meta name="category" content="<?php echo e($post->category_name ?? ''); ?>">
   

    <meta name="coverage" content="Worldwide">
   

    <meta name="distribution" content="Global">
   

    <meta name="rating" content="General">
   

    <meta name="revisit-after" content="7 days">
   

    <meta http-equiv="Expires" content="0">
   

    <meta http-equiv="Pragma" content="no-cache">
   

    <meta http-equiv="Cache-Control" content="no-cache">
   

    <meta name="viewport" content="width=device-width, initial-scale=1">
   

    <link rel="canonical" href="https://www.neuroved.com" />
   


    
    
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/frontend/meta_tag.blade.php ENDPATH**/ ?>