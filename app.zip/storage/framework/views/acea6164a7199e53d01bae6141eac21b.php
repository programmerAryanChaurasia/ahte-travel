<?php $__env->startSection('page-name','Category'); ?>

<?php $__env->startSection('back-page'); ?>
<a href="<?php echo e(route('dashboard.index')); ?>" > Dashboard &nbsp; >  &nbsp;</a> Create Category &nbsp; > &nbsp;<a href="<?php echo e(route('admin.category.list')); ?>" > List </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('content'); ?>

<section class="panel important">
    <?php if($categories['route']=="store"): ?>
        <form action="<?php echo e(route('admin.category.store')); ?>" method="POST">
    <?php else: ?>
        <form action="<?php echo e(route('admin.category.update')); ?>" onsubmit="return confirm('Do you really want to Update the form?');" method="POST">
    <?php endif; ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($categories['id']); ?>" />
        <div class="row ">
            <div class="col-sm-9">
                <div class="container my-4 mx-2">
                    <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="row ">
                        <div class="col-md-6">
                            <label for="" class="form-label">Category <span class="required">*</span></label>
                            <input type="text" name="category" id="" value="<?php echo e($categories['category']); ?>" class="form-control" required>

                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <samp class="validation-error" style="color: red;"><?php echo e($message); ?></samp>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="" class="form-label">Description </label>
                            <textarea class="form-control" id="" value="" name="description" rows="1" required><?php echo e($categories['description']); ?></textarea>
                        </div>
                        <div class="col-md-6" style="margin-top: 30px;">
                            <label for="" class="form-label"> Slug<span class="required">*</span></label>
                            <input type="text" name="slug" id="slug" value="<?php echo e($categories['slug']); ?>" class="form-control" required>
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <samp class="validation-error"><?php echo e($message); ?></samp>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6" style="margin-top: 60px;">
                            <input type="submit" value="Submit">
                            
                        </div>
                        </div>
                    </div>
                    </div>
                </div>

            </div>

            <div class="col-sm-3 px-4" style="margin-top:22px;">
                <div class="col-sm-12 mt-3 ">
                    <label for="your-name" class="form-label">Status <span class="required">*</span></label>
                    <?php if($categories['route']=="store"): ?>
                        <select class="form-select" name="status" data-live-search="true" data-container="body">
                            <option value="1">Active </option>
                            <option value="0">Dactive</option>
                        </select>
                    <?php elseif($categories['status']=="1"): ?>
                        <select class="form-select" name="status" data-live-search="true" data-container="body">
                            <option value="1">Active </option>
                            <option value="0">Dactive</option>
                        </select>
                    <?php else: ?>
                        <select class="form-select" name="status" data-live-search="true" data-container="body">
                            <option value="0">Dactive </option>
                            <option value="1">Active</option>
                        </select>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel projects\website\datascience\resources\views/admin/category/index.blade.php ENDPATH**/ ?>