
<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('layouts.frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</head>
<body>
    <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.frontend.home_page_mobile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.frontend.header2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid home-container">
        <div class="container home-container">

            <?php echo $__env->make('layouts.frontend.home_page_pc_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <div class="destop-center-content">

                <?php echo $__env->yieldContent('content'); ?>
            </div>

            <?php echo $__env->make('layouts.frontend.right_content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

    </div>
    <br>


    <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    

    <script>
        function openNav() {
            document.getElementById("myNav").style.width = "60%";
        }

        function closeNav() {
            document.getElementById("myNav").style.width = "0%";
        }
    </script>
</body>

</html>
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/frontend/layout.blade.php ENDPATH**/ ?>