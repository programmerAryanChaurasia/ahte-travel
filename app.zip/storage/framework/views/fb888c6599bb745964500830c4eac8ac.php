<div class="destop-right-content">
    

</div>
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/frontend/right_content.blade.php ENDPATH**/ ?>