<?php $__env->startSection('page-name','Sub Category'); ?>

<?php $__env->startSection('back-page'); ?>
<a href="<?php echo e(route('dashboard.index')); ?>" > Dashboard &nbsp; >  &nbsp;</a>  Create Sub Category &nbsp; > &nbsp; <a href="<?php echo e(route('admin.sub-category.list')); ?>" > List </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


        <section class="panel important">
            <?php if($sub_categories['route']=="store"): ?>
                <form action="<?php echo e(route('admin.sub-category.store')); ?>" method="post">
            <?php else: ?>
                <form action="<?php echo e(route('admin.sub-category.update')); ?>" onsubmit="return confirm('Do you really want to Update the form?');" method="POST">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($sub_categories['id']); ?>" />
                    <div class="row">
                        <div class="col-sm-9">
                            <div class="container my-5 mx-2">
                                <div class="row justify-content-center">
                                <div class="col-lg-12">
                                    <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="" class="form-label">Select Category <span class="required">*</span></label>
                                        <select class="form-select" name="category" data-live-search="true" data-container="body" required>
                                            <option selected disabled>Select Category</option>
                                            <?php $__empty_1 = true; $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php if($cat->category == $sub_categories['category']): ?>
                                                    <option value="<?php echo e($cat->id); ?>" selected><?php echo e($cat->category); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                        <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <samp class="validation-error" style="color: red;"><?php echo e($message); ?></samp>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="" class="form-label"> Sub Category <span class="required">*</span></label>
                                        <input type="text" name="sub_category" id="" value="<?php echo e($sub_categories['sub_category']); ?>"  class="form-control" required>
                                        <?php $__errorArgs = ['sub_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <samp class="validation-error" style="color: red;"><?php echo e($message); ?></samp>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="" class="form-label">Description </label>
                                        <textarea class="form-control" id="" name="description" rows="1"><?php echo e($sub_categories['description'] ?? ""); ?></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <samp class="validation-error" style="color: red;"><?php echo e($message); ?></samp>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="" class="form-label" >Slug <span class="required">*</span></label>
                                        <input type="text" class="form-control" id="" value="<?php echo e($sub_categories['slug']); ?>" name="slug" rows="1" required>
                                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <samp class="validation-error" style="color: red;"><?php echo e($message); ?></samp>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    </div>
                                </div>
                                </div>
                            </div>

                        </div>

                        <div class="col-sm-3 px-4" style="margin-top:45px;">
                            <div class="col-sm-12 mt-3 ">
                                <label for="your-name" class="form-label">Status <span class="required">*</span></label>
                                <?php if($sub_categories['route']=="store"): ?>
                                    <select class="form-select" name="status" data-live-search="true" data-container="body">
                                        <option value="1">Active </option>
                                        <option value="0">Dactive</option>
                                    </select>
                                <?php elseif($sub_categories['status']=="1"): ?>
                                    <select class="form-select" name="status" data-live-search="true" data-container="body">
                                        <option value="1">Active </option>
                                        <option value="0">Dactive</option>
                                    </select>
                                <?php else: ?>
                                    <select class="form-select" name="status" data-live-search="true" data-container="body">
                                        <option value="0">Dactive </option>
                                        <option value="1">Active</option>
                                    </select>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-12" style="margin-top:65px;">
                                <button type="submit" class="btn btn-dark w-100 fw-bold" >Submit</button>
                            </div>

                        </div>
                    </div>
                </form>
        </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/admin/sub-category/index.blade.php ENDPATH**/ ?>