<header role="banner">
    <h1>Aryan Chaurasia</h1>
    <ul class="utilities">
        <br>
        <li class="users"><a href="#">My Account</a></li>

        <li class="logout warn"><a class="logout warn" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
        <!-- <li class="logout warn"><a href="">Log Out</a></li> -->
    </ul>
</header>
<?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/layouts/admin/header.blade.php ENDPATH**/ ?>