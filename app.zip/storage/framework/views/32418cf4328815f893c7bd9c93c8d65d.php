<!DOCTYPE html>
<html lang="en">

<head>
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('admins/vender/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admins/css/custom.css')); ?>">

</head>
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/admin/head.blade.php ENDPATH**/ ?>