<style>
    .sidebar-scorll{

      max-height: 200px;
      margin-top: 10px;
      margin-bottom: 20px;

      overflow: auto;
      direction: rtl;
    }
    .sidebar-scorll a{
        margin-top: 10px;
    }
    .sidebar-scorll::-webkit-scrollbar {
      width: 5px;
    }

    /* Track */
    .sidebar-scorll::-webkit-scrollbar-track {
      box-shadow: inset 0 0 5px grey;
      border-radius: 10px;
    }



    /* Handle */
    .sidebar-scorll::-webkit-scrollbar-thumb {
      background: #23384e;
      border-radius: 10px;
    }

    /* Handle on hover */
    .sidebar-scorll::-webkit-scrollbar-thumb:hover {
      background: #818f9e;
    }
</style>

<div class="destop-left-sidebar">

    <div class="sidebar">
        <?php $__empty_1 = true; $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <span><?php echo e($cat->category); ?></span>
            <div class="sidebar-scorll">
                <div style="direction: ltr; margin-left:5px;">
                    <?php $__empty_2 = true; $__currentLoopData = $sub_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php if($cat->id == $sub_cat->categories_id): ?>
                            <a href="/<?php echo e($cat->slug); ?>/<?php echo e($sub_cat->slug); ?>"><?php echo e($sub_cat->sub_category); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>

        


    </div>

</div>
<?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/layouts/frontend/home_page_pc_sidebar.blade.php ENDPATH**/ ?>