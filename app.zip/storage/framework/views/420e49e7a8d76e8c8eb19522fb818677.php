


<style>
    .sidebar-scorll{

      max-height: 200px;
      margin-top: 10px;
      margin-bottom: 20px;

      overflow: auto;
      direction: rtl;
    }
    .sidebar-scorll a{
        margin-top: 10px;
    }
    .sidebar-scorll::-webkit-scrollbar {
      width: 5px;
    }

    /* Track */
    .sidebar-scorll::-webkit-scrollbar-track {
      box-shadow: inset 0 0 5px grey;
      border-radius: 10px;
    }



    /* Handle */
    .sidebar-scorll::-webkit-scrollbar-thumb {
      background: #23384e;
      border-radius: 10px;
    }

    /* Handle on hover */
    .sidebar-scorll::-webkit-scrollbar-thumb:hover {
      background: #818f9e;
    }
</style>

<div class="mobile-sidebar">
    <div id="myNav" class="overlay">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="sidebar">

            <span style="margin-left:10px;">Web Development</span>
            <div class="sidebar-scorll">
                <div style="direction: ltr; margin-left:5px;">
                    <a href="#"> HTML Tutorial</a>
                    <a href="#">CSS Tutorial</a>
                    <a href="#">JavaScript Tutorial</a>
                    <a href="#">jQuery Tutorial</a>
                    <a href="#">Bootstrap Tutorial</a>
                    <a href="#">PHP Tutorial</a>
                    <a href="#">SQL Tutorial</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>
                </div>
            </div>

            <span style="margin-left:10px;">Web Development</span>
            <div class="sidebar-scorll">
                <div style="direction: ltr; margin-left:5px;">
                    <a href="#"> HTML Tutorial</a>
                    <a href="#">CSS Tutorial</a>
                    <a href="#">JavaScript Tutorial</a>
                    <a href="#">jQuery Tutorial</a>
                    <a href="#">Bootstrap Tutorial</a>
                    <a href="#">PHP Tutorial</a>
                    <a href="#">SQL Tutorial</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>
                </div>
            </div>

            <span style="margin-left:10px;">Web Development</span>
            <div class="sidebar-scorll">
                <div style="direction: ltr; margin-left:5px;">
                    <a href="#"> HTML Tutorial</a>
                    <a href="#">CSS Tutorial</a>
                    <a href="#">JavaScript Tutorial</a>
                    <a href="#">jQuery Tutorial</a>
                    <a href="#">Bootstrap Tutorial</a>
                    <a href="#">PHP Tutorial</a>
                    <a href="#">SQL Tutorial</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>
                </div>
            </div>

            <span style="margin-left:10px;">Web Development</span>
            <div class="sidebar-scorll">
                <div style="direction: ltr; margin-left:5px;">
                    <a href="#"> HTML Tutorial</a>
                    <a href="#">CSS Tutorial</a>
                    <a href="#">JavaScript Tutorial</a>
                    <a href="#">jQuery Tutorial</a>
                    <a href="#">Bootstrap Tutorial</a>
                    <a href="#">PHP Tutorial</a>
                    <a href="#">SQL Tutorial</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>
                </div>
            </div>

            <span style="margin-left:10px;">Web Development</span>
            <div class="sidebar-scorll">
                <div style="direction: ltr; margin-left:5px;">
                    <a href="#"> HTML Tutorial</a>
                    <a href="#">CSS Tutorial</a>
                    <a href="#">JavaScript Tutorial</a>
                    <a href="#">jQuery Tutorial</a>
                    <a href="#">Bootstrap Tutorial</a>
                    <a href="#">PHP Tutorial</a>
                    <a href="#">SQL Tutorial</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>

                    <a href="#"> HTML Examples</a>
                    <a href="#">CSS Examples</a>
                    <a href="#">JavaScript Examples</a>
                    <a href="#">jQuery Examples</a>
                    <a href="#">Bootstrap Examples</a>
                    <a href="#">PHP Examples</a>
                </div>
            </div>


        </div>
    </div>

</div>

<?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/layouts/frontend/home_page_mobile_sidebar.blade.php ENDPATH**/ ?>