
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <meta name="keywords" content="<?php echo $__env->yieldContent('age'); ?>">
    <!-- This meta tag is used to define the keywords for search engines to help them understand what the webpage is about. It is recommended to use only relevant and specific keywords that are related to the content of the webpage. -->

    <meta name="description" content="150 words">
    <!-- This meta tag is used to define a short description of the webpage. The description should be concise and should accurately summarize the content of the webpage in a few sentences. -->

    
    <!-- This meta tag is used to refresh the webpage after a specified time interval. In this case, the webpage will refresh every 600 seconds. -->

    <meta name="subject" content="your website's subject">
    <!-- This meta tag is used to define the subject or topic of the webpage. It is useful for search engines and can help to improve the ranking of the webpage in search results. -->

    <meta name="copyright" content="company name">
    <!-- This meta tag is used to define the copyright information for the webpage. -->

    <meta name="language" content="EN">
    <!-- This meta tag is used to define the language of the webpage. This information is useful for search engines and can help to improve the ranking of the webpage in search results. -->

    <meta name="robots" content="index,follow, noindex, nofollow, none">
    <!-- This meta tag is used to instruct search engine robots about how to index and follow links on the webpage. The different values of the content attribute have different meanings and can be used to control the behavior of search engine robots.

    index: allows the page to be indexed by search engines
    follow: allows links on the page to be followed by search engines
    noindex: prevents the page from being indexed by search engines
    nofollow: prevents links on the page from being followed by search engines
    none: combines noindex and nofollow, meaning the page won't be indexed and links won't be followed by search engines -->

    <meta name="revised" content="Sunday, July 18th, 2010, 5:15 pm">
    <!-- This meta tag is used to define the last date and time the webpage was revised. It is useful for keeping track of changes to the webpage and can help to improve the ranking of the webpage in search results. -->

    <meta name="abstract" content="">
    <!-- This meta tag is used to define a brief summary or abstract of the webpage. It is similar to the description meta tag, but is typically shorter and more focused. -->

    <meta name="topic" content="">
    <!-- This meta tag is used to define the topic of the webpage. It is similar to the subject meta tag, but is typically more specific. -->

    <meta name="summary" content="">
    <!-- This meta tag is used to define a summary of the content of the webpage. It is similar to the description meta tag, but is typically shorter and more focused. -->

    <meta name="Classification" content="Business">
    <!-- This meta tag is used to define the classification or category of the webpage. It is useful for search engines and can help to improve the ranking of the webpage in search results. -->

    <meta name="author" content="name, email@hotmail.com">
    <!-- This meta tag is used to define the author of the webpage. It typically includes the name and email address of the author. -->

    <meta name="designer" content="">
    <!-- This meta tag is used to define the designer of the webpage. It is typically used in conjunction with the author meta tag. -->

    <meta name="reply-to" content="email@hotmail.com">
    <!-- This meta tag is used to define the email address to which replies to the webpage should be sent. -->

    <meta name="owner" content="">
    <!-- This meta tag is used to define the owner of the webpage. It is typically used in conjunction with the author meta tag. -->

    <meta name="url" content="http://www.websiteaddrress.com">
    <!-- This meta tag is used to define the URL of the webpage -->

    <meta name="identifier-URL" content="http://www.websiteaddress.com">
    <!-- This tag specifies the URL that uniquely identifies the current page. This URL can be different from the actual URL of the page, and can be useful in cases where the page is accessed through multiple URLs or domains. -->

    <meta name="directory" content="submission">
    <!-- This tag specifies the category of the web page for web directories. Directories are typically used to organize websites by topic, and this tag can help directory editors identify the appropriate category for the page. -->

    <meta name="category" content="">
    <!-- This tag specifies the category or topic of the web page, and can be useful for search engines or directory editors to understand the content of the page. -->

    <meta name="coverage" content="Worldwide">
    <!-- This tag specifies the geographic coverage of the web page, and can be useful for search engines or other services that provide location-based search results or recommendations. -->

    <meta name="distribution" content="Global">
    <!-- This tag specifies the distribution of the web page, and can be useful for search engines or other services that provide regional search results or recommendations. -->

    <meta name="rating" content="General">
    <!-- This tag specifies the content rating of the web page, which can be useful for filtering content based on age or other factors. The value "General" indicates that the content is suitable for all ages. -->

    <meta name="revisit-after" content="7 days">
    <!-- This tag specifies the number of days after which the search engine should revisit the page to check for updates. This can be useful for search engines to understand how frequently the page is updated. -->

    <meta http-equiv="Expires" content="0">
    <!-- This tag specifies the expiration time of the web page, which can be useful for caching purposes. A value of "0" indicates that the page should not be cached. -->

    <meta http-equiv="Pragma" content="no-cache">
    <!-- This tag specifies the cache control policy for the web page, and can be useful for controlling how the page is cached or stored by browsers or proxies. -->

    <meta http-equiv="Cache-Control" content="no-cache">
    <!-- This tag specifies the cache control policy for the web page, and can be useful for controlling how the page is cached or stored by browsers or proxies. -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- This tag specifies the viewport settings for the web page, and can be useful for mobile devices or responsive design. The values "width=device-width" and "initial-scale=1" indicate that the page should be rendered at the device width and with an initial zoom level of 100%. -->

    <link rel="canonical" href="https://www.wscubetech.com/full-stack-developer-course.html" />
    <!-- It Prevent from duplicate Url-->


    
    <meta property="og:title" content="WsCube Tech: Online Certification Courses & Live Training" />
    <meta property="og:site_name" content="WsCube Tech" />
    <meta property="og:url" content=https://www.wscubetech.com />
    <meta property="og:description" content="WsCube Tech offers the best job-oriented online certification courses in digital marketing, web/app development, cyber security, data science & more." />
    <meta property="og:type" content="business.business" />
    <meta property="og:image" content="https://www.wscubetech.com/images/wscube-tech-logo.svg" />
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@wscubetechindia">
    <meta name="twitter:title" content="WsCube Tech: Online Certification Courses & Live Training">
    <meta name="twitter:description" content="WsCube Tech offers the best job-oriented online certification courses in digital marketing, web/app development, cyber security, data science & more.">
    <meta name="twitter:image" content="https://www.wscubetech.com/images/wscube-tech-logo.svg">
    <meta itemprop="name" content="WsCube Tech" />
    <meta itemprop="description" content="WsCube Tech was established in the year 2010 with an aim to become the fastest emerging Offshore Outsourcing Company which will aid its client to grow wider with rapid pace." />
    <meta itemprop="image" content="https://www.wscubetech.com/images/wordpress_service-min.png" />
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/admin/meta_tag.blade.php ENDPATH**/ ?>