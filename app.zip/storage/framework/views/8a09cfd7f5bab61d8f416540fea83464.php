


<div class="destop-left-sidebar">

    <div class="sidebar">
        <span><?php echo e($cat->category ?? ''); ?></span>

        

            <?php $__empty_1 = true; $__currentLoopData = $sub_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <?php if( $post->categories_id == $sub_cat->categories_id): ?>

                    <a href="/<?php echo e($post->category_slug); ?>/<?php echo e($sub_cat->slug); ?>"><?php echo e($sub_cat->sub_category); ?></a>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <h5>comming soon...</h5>
            <?php endif; ?>
        




    </div>

</div>



<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/frontend/sidebar-post.blade.php ENDPATH**/ ?>