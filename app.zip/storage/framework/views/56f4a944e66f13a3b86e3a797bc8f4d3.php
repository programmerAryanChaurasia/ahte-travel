




<!DOCTYPE html>
<html lang="en">
    <?php echo $__env->make('layouts.frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<body>
    <div class="wrapper">
        <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


       <?php echo $__env->make('layouts.frontend.js-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


    <?php echo $__env->yieldContent('js'); ?>
</body>


</html>
<?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/layouts/frontend/layout.blade.php ENDPATH**/ ?>