<?php $__env->startSection('page-name','Comment'); ?>

<?php $__env->startSection('back-page'); ?>
<a href="#" > Page1 &nbsp; >  &nbsp;</a> <a href="#" > Page2 &nbsp; > &nbsp;</a> <a href="#" > Page3 </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="panel important">

        <h1>Comment Content Here</h1>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/admin/comment/index.blade.php ENDPATH**/ ?>