<style>
    .pg-footer a {
    color: #fff;
    text-decoration: none;
    }
    .pg-footer .pg-footer {
    font-family: 'Roboto', sans-serif;
    }


    .pg-footer .footer {
        background-color: #071d41;
        color: black;
        z-index: 20;
    }
    .pg-footer .footer-wave-svg {
        background-color: transparent;
        display: block;
        height: 30px;
        position: relative;
        top: -1px;
        width: 100%;
    }
    .pg-footer .footer-wave-path {
        fill: #fafafa;
    }

    .pg-footer .footer-content {
        margin-left: auto;
        margin-right: auto;
        max-width: 1230px;
        padding: 40px 15px 450px;
        position: relative;
    }

    .pg-footer  .footer-content-column {
        box-sizing: border-box;
        float: left;
        padding-left: 15px;
        padding-right: 15px;
        width: 100%;
        color: #fff;
    }

    .pg-footer  .footer-content-column ul li a {
    color: #fff;
    text-decoration: none;
    }

    .pg-footer .footer-logo-link {
        display: inline-block;
    }
    .pg-footer  .footer-menu {
        margin-top: 30px;
    }

    .pg-footer .footer-menu-name {
        color: #fffff2;
        font-size: 15px;
        font-weight: 900;
        letter-spacing: .1em;
        line-height: 18px;
        margin-bottom: 0;
        margin-top: 0;
        text-transform: uppercase;
    }
    .pg-footer .footer-menu-list {
        list-style: none;
        margin-bottom: 0;
        margin-top: 10px;
        padding-left: 0;
    }
    .pg-footer .footer-menu-list li {
        margin-top: 5px;
    }

    .pg-footer .footer-call-to-action-description {
        color: #fffff2;
        margin-top: 10px;
        margin-bottom: 20px;
    }
    .pg-footer .footer-call-to-action-button:hover {
        background-color: #fffff2;
        color: #00bef0;
    }
    .pg-footer .button:last-of-type {
        margin-right: 0;
    }
    .pg-footer .footer-call-to-action-button {
        background-color: #027b9a;
        border-radius: 21px;
        color: #fffff2;
        display: inline-block;
        font-size: 11px;
        font-weight: 900;
        letter-spacing: .1em;
        line-height: 18px;
        padding: 12px 30px;
        margin: 0 10px 10px 0;
        text-decoration: none;
        text-transform: uppercase;
        transition: background-color .2s;
        cursor: pointer;
        position: relative;
    }
    .pg-footer .footer-call-to-action {
        margin-top: 30px;
    }
    .pg-footer .footer-call-to-action-title {
        color: #fffff2;
        font-size: 14px;
        font-weight: 900;
        letter-spacing: .1em;
        line-height: 18px;
        margin-bottom: 0;
        margin-top: 0;
        text-transform: uppercase;
    }
    .pg-footer .footer-call-to-action-link-wrapper {
        margin-bottom: 0;
        margin-top: 10px;
        color: #fff;
        text-decoration: none;
    }
    .pg-footer .footer-call-to-action-link-wrapper a {
        color: #fff;
        text-decoration: none;
    }





    .pg-footer .footer-social-links {
        bottom: 0;
        height: 54px;
        position: absolute;
        right: 0;
        width: 236px;
    }

    .pg-footer .footer-social-amoeba-svg {
        height: 54px;
        left: 0;
        display: block;
        position: absolute;
        top: 0;
        width: 236px;
    }

    .footer-social-amoeba-path {
        fill: #027b9a;
    }

    .footer-social-link.linkedin {
        height: 26px;
        left: 3px;
        top: 11px;
        width: 26px;
    }

    .pg-footer .footer-social-link {
        display: block;
        padding: 10px;
        position: absolute;
    }

    .pg-footer .hidden-link-text {
        position: absolute;
        clip: rect(1px 1px 1px 1px);
        clip: rect(1px,1px,1px,1px);
        -webkit-clip-path: inset(0px 0px 99.9% 99.9%);
        clip-path: inset(0px 0px 99.9% 99.9%);
        overflow: hidden;
        height: 1px;
        width: 1px;
        padding: 0;
        border: 0;
        top: 50%;
    }

    .pg-footer .footer-social-icon-svg {
        display: block;
    }

    .pg-footer .footer-social-icon-path {
        fill: #fffff2;
        transition: fill .2s;
    }

    .pg-footer .footer-social-link.twitter {
        height: 28px;
        left: 62px;
        top: 3px;
        width: 28px;
    }

    .pg-footer .footer-social-link.youtube {
        height: 24px;
        left: 123px;
        top: 12px;
        width: 24px;
    }

    .pg-footer .footer-social-link.github {
        height: 34px;
        left: 172px;
        top: 7px;
        width: 34px;
    }

    .pg-footer .footer-copyright {
        background-color: #027b9a;
        color: #fff;
        padding: 15px 30px;
    text-align: center;
    }

    .pg-footer .footer-copyright-wrapper {
        margin-left: auto;
        margin-right: auto;
        max-width: 1200px;
    }

    .pg-footer .footer-copyright-text {
    color: #fff;
        font-size: 13px;
        font-weight: 400;
        line-height: 18px;
        margin-bottom: 0;
        margin-top: 0;
    }

    .pg-footer .footer-copyright-link {
        color: #fff;
        text-decoration: none;
    }







    /* Media Query For different screens */
    @media (min-width:320px) and (max-width:479px)  { /* smartphones, portrait iPhone, portrait 480x320 phones (Android) */
    .pg-footer .footer-content {
        margin-left: auto;
        margin-right: auto;
        max-width: 1230px;
        padding: 40px 15px 1050px;
        position: relative;
    }
    }
    @media (min-width:480px) and (max-width:599px)  { /* smartphones, Android phones, landscape iPhone */
    .pg-footer .footer-content {
        margin-left: auto;
        margin-right: auto;
        max-width: 1230px;
        padding: 40px 15px 1050px;
        position: relative;
    }
    }
    @media (min-width:600px) and (max-width: 800px)  { /* portrait tablets, portrait iPad, e-readers (Nook/Kindle), landscape 800x480 phones (Android) */
    .pg-footer .footer-content {
        margin-left: auto;
        margin-right: auto;
        max-width: 1230px;
        padding: 40px 15px 1050px;
        position: relative;
    }
    }
    @media (min-width:801px)  { /* tablet, landscape iPad, lo-res laptops ands desktops */

    }
    @media (min-width:1025px) { /* big landscape tablets, laptops, and desktops */

    }
    @media (min-width:1281px) { /* hi-res laptops and desktops */

    }




    @media (min-width: 760px) {
    .pg-footer .footer-content {
        margin-left: auto;
        margin-right: auto;
        max-width: 1230px;
        padding: 40px 15px 450px;
        position: relative;
    }

    .pg-footer .footer-wave-svg {
        height: 50px;
    }

    .pg-footer .footer-content-column {
        width: 24.99%;
    }
    }
    @media (min-width: 568px) {
    /* .footer-content-column {
        width: 49.99%;
    } */
    }

</style>



<span></span>
<p class="content-footer-saperater" style="clear: both;"></p>

<div class="pg-footer">
<footer class="footer">
  <svg class="footer-wave-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 100" preserveAspectRatio="none">
    <path class="footer-wave-path" d="M851.8,100c125,0,288.3-45,348.2-64V0H0v44c3.7-1,7.3-1.9,11-2.9C80.7,22,151.7,10.8,223.5,6.3C276.7,2.9,330,4,383,9.8 c52.2,5.7,103.3,16.2,153.4,32.8C623.9,71.3,726.8,100,851.8,100z"></path>
  </svg>
  <div class="footer-content">
    <div class="footer-content-column">
      <div class="footer-logo">
        <a class="footer-logo-link" href="#">
          <span class="hidden-link-text">LOGO</span>
          <h1>LOGO</h1>
        </a>
      </div>
      <div class="footer-menu">
        <h2 class="footer-menu-name"> Get Started</h2>
        <ul id="menu-get-started" class="footer-menu-list">
          <li class="menu-item menu-item-type-post_type menu-item-object-product">
            <a href="#">Start</a>
          </li>
          <li class="menu-item menu-item-type-post_type menu-item-object-product">
            <a href="#">Documentation</a>
          </li>
          <li class="menu-item menu-item-type-post_type menu-item-object-product">
            <a href="#">Installation</a>
          </li>
        </ul>
      </div>
    </div>
    <div class="footer-content-column">
      <div class="footer-menu">
        <h2 class="footer-menu-name"> Company</h2>
        <ul id="menu-company" class="footer-menu-list">
          <li class="menu-item menu-item-type-post_type menu-item-object-page">
            <a href="#">Contact</a>
          </li>
          <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
            <a href="#">News</a>
          </li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page">
            <a href="#">Careers</a>
          </li>
        </ul>
      </div>
      <div class="footer-menu">
        <h2 class="footer-menu-name"> Legal</h2>
        <ul id="menu-legal" class="footer-menu-list">
          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-170434">
            <a href="#">Privacy Notice</a>
          </li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page">
            <a href="#">Terms of Use</a>
          </li>
        </ul>
      </div>
    </div>
    <div class="footer-content-column">
      <div class="footer-menu">
        <h2 class="footer-menu-name"> Quick Links</h2>
        <ul id="menu-quick-links" class="footer-menu-list">
          <li class="menu-item menu-item-type-custom menu-item-object-custom">
            <a target="_blank" rel="noopener noreferrer" href="#">Support Center</a>
          </li>
          <li class="menu-item menu-item-type-custom menu-item-object-custom">
            <a target="_blank" rel="noopener noreferrer" href="#">Service Status</a>
          </li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page">
            <a href="#">Security</a>
          </li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page">
            <a href="#">Blog</a>
          </li>
          <li class="menu-item menu-item-type-post_type_archive menu-item-object-customer">
            <a href="#">Customers</a></li>
          <li class="menu-item menu-item-type-post_type menu-item-object-page">
            <a href="#">Reviews</a>
          </li>
        </ul>
      </div>
    </div>
    <div class="footer-content-column">
      <div class="footer-call-to-action">
        <h2 class="footer-call-to-action-title"> Let's Chat</h2>
        <p class="footer-call-to-action-description"> Have a support question?</p>
        <a class="footer-call-to-action-button button" href="#" target="_self"> Get in Touch </a>
      </div>
      <div class="footer-call-to-action">
        <h2 class="footer-call-to-action-title"> You Call Us</h2>
        <p class="footer-call-to-action-link-wrapper"> <a class="footer-call-to-action-link" href="tel:0124-64XXXX" target="_self"> 0124-64XXXX </a></p>
      </div>
    </div>
    <div class="footer-social-links"> <svg class="footer-social-amoeba-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 236 54">
        <path class="footer-social-amoeba-path" d="M223.06,43.32c-.77-7.2,1.87-28.47-20-32.53C187.78,8,180.41,18,178.32,20.7s-5.63,10.1-4.07,16.7-.13,15.23-4.06,15.91-8.75-2.9-6.89-7S167.41,36,167.15,33a18.93,18.93,0,0,0-2.64-8.53c-3.44-5.5-8-11.19-19.12-11.19a21.64,21.64,0,0,0-18.31,9.18c-2.08,2.7-5.66,9.6-4.07,16.69s.64,14.32-6.11,13.9S108.35,46.5,112,36.54s-1.89-21.24-4-23.94S96.34,0,85.23,0,57.46,8.84,56.49,24.56s6.92,20.79,7,24.59c.07,2.75-6.43,4.16-12.92,2.38s-4-10.75-3.46-12.38c1.85-6.6-2-14-4.08-16.69a21.62,21.62,0,0,0-18.3-9.18C13.62,13.28,9.06,19,5.62,24.47A18.81,18.81,0,0,0,3,33a21.85,21.85,0,0,0,1.58,9.08,16.58,16.58,0,0,1,1.06,5A6.75,6.75,0,0,1,0,54H236C235.47,54,223.83,50.52,223.06,43.32Z"></path>
      </svg>
      <a class="footer-social-link linkedin" href="#" target="_blank">
        <span class="hidden-link-text">Linkedin</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
            <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401m-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4"/>
          </svg>
      </a>
      <a class="footer-social-link twitter" href="#" target="_blank">
        <span class="hidden-link-text">Youtube</span>
        <svg xmlns="http://www.w3.org/2000/svg"  height="30" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
            <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408z"/>
        </svg>

      </a>
      <a class="footer-social-link youtube" href="#" target="_blank">
        <span class="hidden-link-text">Facebook</span>
        <svg xmlns="http://www.w3.org/2000/svg" height="25"  fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
            <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951"/>
        </svg>
      </a>
      <a class="footer-social-link github" href="#" target="_blank">
        <span class="hidden-link-text">Twitter</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
            <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"/>
        </svg>
      </a>
    </div>
  </div>
  <div class="footer-copyright">
    <div class="footer-copyright-wrapper">
      <p class="footer-copyright-text">
        <a class="footer-copyright-link" href="#" target="_self"> ©2020. | Designed By: Pooja Nahelia. | All rights reserved. </a>
      </p>
    </div>
  </div>
</footer>
</div>
<?php /**PATH D:\Laravel projects\website\datascience\resources\views/layouts/frontend/footer.blade.php ENDPATH**/ ?>