<div class="header-wrapper">
    <div class="header">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-2 col-md-3 col-sm-3 col-12">
                    <div class="logo"> <a href="index.html">
                            <svg width="169" height="46" viewBox="0 0 438.65805546667605 62.61027041135102" class="looka-1j8o68f"><defs id="SvgjsDefs6543"><linearGradient id="SvgjsLinearGradient6550"><stop id="SvgjsStop6551" stop-color="#905e26" offset="0"></stop><stop id="SvgjsStop6552" stop-color="#f5ec9b" offset="0.5"></stop><stop id="SvgjsStop6553" stop-color="#905e26" offset="1"></stop></linearGradient><linearGradient id="SvgjsLinearGradient6554"><stop id="SvgjsStop6555" stop-color="#905e26" offset="0"></stop><stop id="SvgjsStop6556" stop-color="#f5ec9b" offset="0.5"></stop><stop id="SvgjsStop6557" stop-color="#905e26" offset="1"></stop></linearGradient><linearGradient id="SvgjsLinearGradient6558"><stop id="SvgjsStop6559" stop-color="#905e26" offset="0"></stop><stop id="SvgjsStop6560" stop-color="#f5ec9b" offset="0.5"></stop><stop id="SvgjsStop6561" stop-color="#905e26" offset="1"></stop></linearGradient></defs><g id="SvgjsG6544" featurekey="nameLeftFeature-0" transform="matrix(2.435818059476061,0,0,2.435818059476061,0.34101478385413203,0.06712237234046015)" fill="url(#SvgjsLinearGradient6550)"><path d="M8.5 5.720000000000001 l5.34 14.28 l-3.26 0 l-1.08 -3.18 l-5.34 0 l-1.12 3.18 l-3.18 0 l5.42 -14.28 l3.22 0 z M6.84 9.24 l-1.86 5.24 l3.7 0 l-1.8 -5.24 l-0.04 0 z M18.22 5.720000000000001 l0 5.48 l5.78 0 l0 -5.48 l3.14 0 l0 14.28 l-3.14 0 l0 -6.16 l-5.78 0 l0 6.16 l-3.14 0 l0 -14.28 l3.14 0 z M40.480000000000004 5.720000000000001 l0 2.64 l-4.28 0 l0 11.64 l-3.14 0 l0 -11.64 l-4.28 0 l0 -2.64 l11.7 0 z M52.800000000000004 5.720000000000001 l0 2.64 l-7.54 0 l0 3.06 l6.92 0 l0 2.44 l-6.92 0 l0 3.5 l7.7 0 l0 2.64 l-10.84 0 l0 -14.28 l10.68 0 z"></path></g><g id="SvgjsG6545" featurekey="inlineSymbolFeature-0" transform="matrix(0.9782854751773596,0,0,0.9782854751773596,143.13028714893585,-17.609138553192473)" fill="url(#SvgjsLinearGradient6554)"><g xmlns="http://www.w3.org/2000/svg" transform="translate(0,-952.36218)"><path style="color:;enable-background:accumulate;" d="m 36,18 8,25 -10,0 -7,-9 -9,0 5,16 -5,16 9,0 7,-9 10,0 -8,25 9,0 15,-25 22,0 c 6.734786,0 10,-2.5187 10,-7 0,-4.64193 -4.59808,-7 -10,-7 L 60,43 45,18 z m -25,4 c 0,0.942809 0.951519,2 2,2 L 33.71875,24 32.4375,20 13,20 c -1.150333,0 -2,1.057191 -2,2 z M 6,38 c 0,0.942809 0.9515191,2 2,2 l 7.6875,0 -1.25,-4 L 8,36 c -1.1503248,0 -2,1.057191 -2,2 z m 0,24 c 0,0.942809 0.9515191,2 2,2 l 6.4375,0 1.25,-4 L 8,60 c -1.1503312,0 -2,1.057191 -2,2 z m 5,16 c 0,0.942809 0.951519,2 2,2 L 32.4375,80 33.71875,76 13,76 c -1.150333,0 -2,1.057191 -2,2 z" transform="translate(0,952.36218)" fill="url(#SvgjsLinearGradient6554)" stroke="none" marker="none" visibility="visible" display="inline" overflow="visible" fill-opacity="1"></path></g></g><g id="SvgjsG6546" featurekey="nameRightFeature-0" transform="matrix(2.435818059476061,0,0,2.435818059476061,238.82354079869057,0.06712237234046015)" fill="url(#SvgjsLinearGradient6558)"><path d="M17.520000000000003 5.720000000000001 l0 2.64 l-4.28 0 l0 11.64 l-3.14 0 l0 -11.64 l-4.28 0 l0 -2.64 l11.7 0 z M26.86 5.720000000000001 c1.2 0 2.1968 0.37 2.99 1.11 s1.19 1.6833 1.19 2.83 c0 1.7867 -0.75334 2.98 -2.26 3.58 l0 0.04 c0.50666 0.14666 0.90332 0.39 1.19 0.73 s0.50332 0.73666 0.64998 1.19 s0.24 1.18 0.28 2.18 c0.05334 1.3067 0.24 2.18 0.56 2.62 l-3.14 0 c-0.17334 -0.44 -0.30668 -1.2667 -0.40002 -2.48 c-0.10666 -1.28 -0.34 -2.1166 -0.7 -2.51 s-0.94666 -0.59 -1.76 -0.59 l-3.16 0 l0 5.58 l-3.14 0 l0 -14.28 l7.7 0 z M25.76 12.18 c0.66666 0 1.19 -0.15 1.57 -0.45 s0.57 -0.83 0.57 -1.59 c0 -0.72 -0.18666 -1.23 -0.56 -1.53 s-0.90668 -0.45 -1.6 -0.45 l-3.44 0 l0 4.02 l3.46 0 z M40.72 5.720000000000001 l5.34 14.28 l-3.26 0 l-1.08 -3.18 l-5.34 0 l-1.12 3.18 l-3.18 0 l5.42 -14.28 l3.22 0 z M39.06 9.24 l-1.86 5.24 l3.7 0 l-1.8 -5.24 l-0.04 0 z M48.08 5.720000000000001 l3.18 10.04 l0.04 0 l3.22 -10.04 l3.24 0 l-4.74 14.28 l-3.54 0 l-4.64 -14.28 l3.24 0 z M69.66 5.720000000000001 l0 2.64 l-7.54 0 l0 3.06 l6.92 0 l0 2.44 l-6.92 0 l0 3.5 l7.7 0 l0 2.64 l-10.84 0 l0 -14.28 l10.68 0 z M75.08 5.720000000000001 l0 11.64 l6.96 0 l0 2.64 l-10.1 0 l0 -14.28 l3.14 0 z"></path></g></svg>
                    </a> </div>
                </div>
                <div class="col-xl-9 col-lg-10 col-md-9 col-sm-12 col-12">
                    <!-- navigations-->
                    <div class="navigation">
                        <div id="navigation">
                            <ul>
                                <li class="active"><a href="/">Home</a></li>
                                
                                <li><a href="<?php echo e(route('packages')); ?>">Packages</a></li>
                                <li><a href="<?php echo e(route('about-us')); ?>">About</a></li>
                                <li><a href="<?php echo e(route('blog-list')); ?>">Blog</a></li>
                                <li><a href="<?php echo e(route('gallery')); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(route('review')); ?>">Review</a></li> 
                                <li><a href="<?php echo e(route('railway')); ?>">Train Ticket</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.navigations-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\new user\Desktop\ahte_travel\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>