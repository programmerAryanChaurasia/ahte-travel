@extends('layouts.admin.layout')

@section('page-name','Tags')

@section('back-page')
<a href="#" > Page1 &nbsp; >  &nbsp;</a> <a href="#" > Page2 &nbsp; > &nbsp;</a> <a href="#" > Page3 </a>
@endsection

@section('content')

    <section class="panel important">

        <h1>Tags Content Here</h1>

    </section>
@endsection
